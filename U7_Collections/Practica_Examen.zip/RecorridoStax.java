import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class RecorridoStax {
    public static void main(String[] args) {

        XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();

        try{
            Integer resultado = 0;
            Integer cont = 0;
            XMLEventReader xmlReader = xmlInputFactory.createXMLEventReader(new FileInputStream("empleados.xml"));

            while(xmlReader.hasNext()){


                XMLEvent xmlEvent = xmlReader.nextEvent();
                if(xmlEvent.isStartElement()){

                    StartElement startElement = xmlEvent.asStartElement();
                    if(startElement.getName().getLocalPart().equals("empleado")){

                        Attribute edadAttribute = (startElement.getAttributeByName(new QName("edad")));
                        Integer edad = Integer.parseInt(edadAttribute.getValue());
                        cont++;
                        resultado += edad;
                    }
                }
            }

            resultado = resultado / cont;

            System.out.println("La media de las edades es"+ resultado );







        } catch (XMLStreamException e) {
            throw new RuntimeException(e);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }


    }


}
