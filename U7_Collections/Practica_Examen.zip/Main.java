import java.util.List;

public class Main {

    public static void main(String[] args) {

        List<Product> lista = Consultas.getProductLines(50.0);

        for (Product p1: lista) {

            System.out.println(p1);
        }



    }

}
