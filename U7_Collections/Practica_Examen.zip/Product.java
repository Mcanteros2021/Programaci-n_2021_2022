public class Product {

    private String productname;
    private String productLine;
    private Double buyPrice;

    public Product(String productname, String productLine, Double buyPrice) {
        this.productname = productname;
        this.productLine = productLine;
        this.buyPrice = buyPrice;
    }

    public Product() {
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getProductLine() {
        return productLine;
    }

    public void setProductLine(String productLine) {
        this.productLine = productLine;
    }

    public Double getBuyPrice() {
        return buyPrice;
    }

    public void setBuyPrice(Double buyPrice) {
        this.buyPrice = buyPrice;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productname='" + productname + '\'' +
                ", productLine='" + productLine + '\'' +
                ", buyPrice=" + buyPrice +
                '}';
    }
}
