package ExamenU6_7;

public class Main {
    public static void main(String[] args) {

        Trabajador t1 = new Trabajador("dgsdng9","Juan","Cantero",30,"Tecnico Superior");
        Trabajador t2 = new Trabajador("dgsdng8","Alvaro","Cantera",40,"Tecnico Superior");
        Trabajador t3 = new Trabajador("dgsdng7","Maria","Cantere",44,"Tecnico Superior");
        Trabajador t4 = new Trabajador("dgsdng6","Mario","Canteri",43,"Tecnico Superior");
        Trabajador t5 = new Trabajador("dgsdng5","Juana","Canteru",37,"Tecnico Superior");
        Trabajador t6 = new Trabajador("dgsdng4","Vicente","Canteran",36,"Tecnico Superior");
        Trabajador t7 = new Trabajador("dgsdng3","Vicenta","Canteron",35,"Tecnico Superior");
        Trabajador t8 = new Trabajador("dgsdng2","Casandra","Canterin",34,"Tecnico Superior");
        Trabajador t9 = new Trabajador("dgsdng1","Pablo","Canterun",33,"Tecnico Superior");
        Trabajador t10 = new Trabajador("dgsdng0","Pepe","Canteren",20,"Tecnico Superior");

        Oferta o1 = new Oferta(44444,"Mal pagado mal acompañado",false);
        Oferta o2 = new Oferta(33333,"Bien pagado mal acompañado",false);
        Oferta o3 = new Oferta(22222,"Mal pagado bien acompañado",false);
        Oferta o4 = new Oferta(11111,"Bien pagado Bien acompañado",false);
        Oferta o5 = new Oferta(55555,"Ni fu ni fa",false);

        SAE s1 = new SAE();

        s1.cargarDatos();

        s1.addOferta(o1);

        s1.addTrabajador(44444, t1);
        s1.addTrabajador(44444, t2);
        s1.removeTrabajador(44444,t1);

        s1.guardarDatos();


        s1.mostrarTrabajadores(44444);



        s1.mostrarOfertas();


        System.out.println(s1.cantidadOfertas(t1.getDni()));


    }
}
