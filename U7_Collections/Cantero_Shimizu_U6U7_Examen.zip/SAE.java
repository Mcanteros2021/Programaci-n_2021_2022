package ExamenU6_7;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.Key;
import java.util.*;

public class SAE {

    private HashMap<Integer, Oferta> ofertas;

    public SAE() {
        this.ofertas = new HashMap<>();
    }

    public boolean addOferta(Oferta o){

        if(ofertas.containsKey(o.getCodigo())){

            System.out.println("La oferta esta repetida");
            return false;

        } else {

            ofertas.put(o.getCodigo(),o);
            return true;

        }
    }

    public boolean addTrabajador(Integer codigo, Trabajador t){

if(ofertas.get(codigo).getTrabajadores().contains(t)){

    System.out.println("El trabajador ya esta apuntado");
    return false;
}else {
    ofertas.get(codigo).getTrabajadores().add(t);
    return true;

    }
    }

    public boolean removeTrabajador(Integer codigo, Trabajador t){

        if(ofertas.get(codigo).getTrabajadores().contains(t)){

            ofertas.get(codigo).getTrabajadores().remove(t);
            return true;

        } else {

            System.out.println("No se encuentra el trabajador");
            return false;
        }

    }

    public void mostrarTrabajadores(Integer codigo){

            int cont = 0;

            for (Trabajador t:
                    ofertas.get(codigo).getTrabajadores()
                 ) {
                System.out.println(t);
                cont++;
            }

        if(cont == 0){

            System.out.println("No hay trabajadores");
        }


        }

        public int cantidadOfertas(String dni){

           Iterator it = ofertas.values().iterator();
           int cont = 0;

           while (it.hasNext()){

               Oferta o = (Oferta) it.next();

               for (Trabajador t:
                       o.getTrabajadores()
               ) { if(t.getDni().equals(dni)){

                   cont++;
               }

               }

           }
               return cont;
            }


        public void guardarDatos(){

            try {
                ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("sae.dat"));


                Iterator it = ofertas.values().iterator();

                while (it.hasNext()) {
                    Oferta o = (Oferta) it.next();
                    oos.writeObject(o);
                }

                oos.close();

            } catch (Exception e) {
                System.out.println(e.getMessage());
            }



        }
    public void cargarDatos(){

        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("sae.dat"));

            while (true) {
                Oferta o = (Oferta)ois.readObject();
                addOferta(o);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
    public void mostrarOfertas(){

        Iterator it = ofertas.values().iterator();
        String cubierto = "";

        while (it.hasNext()){
            Oferta o = (Oferta) it.next();
            if(o.getCubierto() == true){
                cubierto = "cubierto";
            } else {

                cubierto = "No cubierto";
            }

            System.out.println(o.getCodigo()+ o.getDescripcion()+ cubierto);

        }



    }










    @Override
    public String toString() {
        return "SAE{" +
                "ofertas=" + ofertas +
                '}';
    }
}


