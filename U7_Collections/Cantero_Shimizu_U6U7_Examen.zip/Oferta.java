package ExamenU6_7;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Oferta {

    private int codigo;
    private String descripcion;
    private Set<Trabajador> trabajadores;
    private Boolean cubierto;

    public Oferta(int codigo, String descripcion, Boolean cubierto) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.trabajadores = new HashSet<>();
        this.cubierto = cubierto;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Set<Trabajador> getTrabajadores() {
        return trabajadores;
    }

    public void setTrabajadores(Set<Trabajador> trabajadores) {
        this.trabajadores = trabajadores;
    }

    public Boolean getCubierto() {
        return cubierto;
    }

    public void setCubierto(Boolean cubierto) {
        this.cubierto = cubierto;
    }

    @Override
    public String toString() {
        return "Oferta{" +
                "codigo=" + codigo +
                ", descripcion='" + descripcion + '\'' +
                ", trabajadores=" + trabajadores +
                ", cubierto=" + cubierto +
                '}';
    }
}
