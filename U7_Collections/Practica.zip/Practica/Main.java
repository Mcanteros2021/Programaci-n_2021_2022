package Practica;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Main {
    public static void main(String[] args) {

        Map<Integer,Atleta> mapAtleta = new HashMap<>();


    }
}
