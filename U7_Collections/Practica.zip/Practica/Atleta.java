package Practica;

public class Atleta {

    private String nombre;
    private String pais;
    private Integer marca;
    private Categoria categoria;
    private Boolean finisher;
    private Integer dorsal;

    static int id = 0;

    public Atleta(String nombre, String pais, Categoria categoria) {
        this.nombre = nombre;
        this.pais = pais;
        this.marca = 0;
        this.categoria = categoria;
        this.finisher = false;
        this.dorsal = id;
        id++;

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public Integer getMarca() {
        return marca;
    }

    public void setMarca(Integer marca) {
        this.marca = marca;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public Boolean getFinisher() {
        return finisher;
    }

    public void setFinisher(Boolean finisher) {
        this.finisher = finisher;
    }

    public Integer getDorsal() {
        return dorsal;
    }

    public void setDorsal(Integer dorsal) {
        this.dorsal = dorsal;
    }
}
