package Practica;

public enum Categoria {
    SENIOR,JUNIOR,VETERANO
}
