package Practica;

import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Maraton {

    private Map<Categoria, Set<Atleta>> atletas;



    public boolean inscribir(){

        Scanner sc = new Scanner(System.in);
        String nombre,pais;



        System.out.println("Introduzca los datos del atleta");



    }


}

