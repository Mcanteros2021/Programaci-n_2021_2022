import java.io.*;
import java.util.*;

public class main {
    public static void main(String[] args) {

        Map<String,alumnos> mapAlum = new HashMap<>();
        Set<alumnos> setAlum = new TreeSet<>();
        Scanner sc = new Scanner(System.in);
        String opcion;

        cargarAlumnos(mapAlum, setAlum);


        do {
            mostrarMenu();
            System.out.println("Introduce la opción");
            opcion = sc.nextLine();

            switch (opcion) {
                case "1":
                    alumnos a = crearAlumno();
                    mapAlum.put(a.getDNI(),a);
                    break;
                case "2":
                    borrarAlumno(mapAlum,setAlum);
                    break;
                case "3":
                    visualizarAlumnos(mapAlum);
                    break;
                case "4":

                case "5":

                case "6":
                    guardarAlumnos(mapAlum);
                    System.out.println(mapAlum);
                    break;
                default:
                    System.out.println("Opción incorrecta");

            }
        } while(!opcion.equals("6"));



    }



    public static void mostrarMenu() {
        System.out.println("Elige una opción");
        System.out.println("1- Insertar alumno");
        System.out.println("2- Borrar alumno");
        System.out.println("3- Mostrar alumnos");
        System.out.println("4- Mostrar alumno");
        System.out.println("5- Modificar alumno");
        System.out.println("6- Salir");
    }

    public static alumnos crearAlumno() {
        Scanner sc = new Scanner(System.in);
        String nombre,apellidos,direccion,DNI,email,curso;
        Boolean dual;
        System.out.println("Introduce el Nombre");
        nombre = sc.nextLine();
        System.out.println("Introduce los apellidos");
        apellidos = sc.nextLine();
        System.out.println("Introduce la direccion");
        direccion = sc.nextLine();
        System.out.println("Introduce el DNI");
        DNI = sc.nextLine();
        System.out.println("Introduce el mail");
        email = sc.nextLine();
        System.out.println("Introduce el curso");
        curso = sc.nextLine();
        System.out.println("Introduce el dual");
        dual = sc.nextBoolean();

        return new alumnos(nombre,apellidos,direccion,DNI,email,curso,dual);
    }

    public static void guardarAlumnos(Map<String,alumnos> empleados) {

        ObjectOutputStream oos= null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream("alumnos.dat"));

            Collection<alumnos> lista = empleados.values();
            for(alumnos e : lista) {
                oos.writeObject(e);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public static void visualizarAlumnos(Map<String,alumnos> alumnos) {
        Collection<alumnos> lista = alumnos.values();
        Iterator it = lista.iterator();
        while (it.hasNext()) {
            alumnos e = (alumnos) it.next();
            System.out.println(e);
        }
    }
    public static void borrarAlumno(Map<String,alumnos> alumnos,Set<alumnos> setalum) {

        Scanner sc = new Scanner(System.in);
        String dni;

        do {
            System.out.println("Introduce el DNI del alumno a borrar");
            dni = sc.nextLine();

            if (alumnos.containsKey(dni)) {
                alumnos.remove(dni);
                setalum.remove(dni);
            } else if (!dni.equals(("fin"))){
                System.out.println("El alumno no existe");
            }
        } while (!dni.equals("fin"));

    }

    public static void visualizarAlumno(Map<String,alumnos> alumnos) {
        Scanner sc = new Scanner(System.in);
        String curso;

        System.out.println("Introduce el Curso del alumno a buscar");
        curso = sc.nextLine();

        if (alumnos.containsKey(curso)) {
            System.out.println(alumnos.get(curso));
        } else {
            System.out.println("No hay alumnos de ese curso");
        }
    }

        public static void cargarAlumnos(Map<String,alumnos> alumnos, Set<alumnos> setalum) {

        ObjectInputStream ois = null;

        try {

            ois = new ObjectInputStream(new FileInputStream("alumnos.dat"));

            while (true) {

                alumnos e = (alumnos)ois.readObject();
                alumnos.put(e.getDNI(),e);
                setalum.add(e);
            }

        } catch (IOException e) {
            //e.printStackTrace();
        } catch (ClassNotFoundException e) {
            //e.printStackTrace();
        } finally {
            try {
                if(ois != null){
                    ois.close();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }





    }

