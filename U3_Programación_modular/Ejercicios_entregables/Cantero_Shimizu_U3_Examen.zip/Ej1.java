import java.util.Arrays;
import java.util.Scanner;

public class Ej1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduzca el tamaño de la longitud del vector 1");

        int[]v1 = new int[sc.nextInt()];

        System.out.println("Introduzca el tamaño de la longitud del vector 2");

        int[]v2 = new int[sc.nextInt()];


        for (int i = 0; i < v1.length; i++) {
            System.out.println("Escriba el valor para la posición "+i+" del vector 1");
            v1[i] = sc.nextInt();
        }

        for (int i = 0; i < v2.length; i++) {
            System.out.println("Escriba el valor para la posición "+i+" del vector 2");
            v2[i] = sc.nextInt();
        }

        System.out.println("Su Array de medias es"+Arrays.toString(mediaVectores(v1,v2)));

    }
public static Float[] mediaVectores(int[]v1,int[]v2){

        Float media[] = new Float[0];


        if(v1.length > v2.length){
            for (int i = 0; i < v1.length; i++) {
                if(i < v2.length){
                    media = Arrays.copyOf(media,media.length + 1);
                    media[media.length - 1] = ((float)(v1[i] + v2[i])/2);
                }else {
                    media = Arrays.copyOf(media,media.length + 1);
                    media[media.length - 1] = ((float)(v1[i]));
                }
            }
        }else {
            for (int i = 0; i < v2.length; i++) {
                if(i < v1.length){
                    media = Arrays.copyOf(media,media.length + 1);
                    media[media.length - 1] = ((float)(v1[i] + v2[i])/2);
                }else {
                    media = Arrays.copyOf(media,media.length + 1);
                    media[media.length - 1] = ((float)(v2[i]));
                }
            }
        }

    return media;





}

}
