import java.util.Arrays;

public class Ej2 {
    public static void main(String[] args) {

        int[]array = {1,2,4,5,6,7};
        int num = 3;
        int pos = 2;


        System.out.println(Arrays.toString(insertarValor(num,pos,array)));


    }
    public static int[]insertarValor(int valor, int pos, int[]v1){

        int[]vFinal = new int[v1.length + 1];


        for (int i = 0; i < vFinal.length; i++) {

            if(pos < i){
                vFinal[i] = v1[i - 1];

            }else if(pos == i) {
                vFinal[i] = valor;
            } else if(pos > i){
                vFinal[i] = v1[i];
            }
        }

        return vFinal;
    }
}
