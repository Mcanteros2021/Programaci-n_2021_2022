import java.util.Arrays;

public class Ej4 {
    public static void main(String[] args) {

        int[][] matriz = new int[4][4];
        int cont = 0;

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {

                matriz[i][j] = cont;
                cont++;
            }
        }

        for (int[]x:
             matriz) {
            System.out.println(Arrays.toString(x));
        }

        System.out.println();

        for (int[]x:
                eliminarFilasPares(matriz)) {
            System.out.println(Arrays.toString(x));
        }

        System.out.println();

        for (int[]x:
               eliminarFilasImpares(matriz)) {
            System.out.println(Arrays.toString(x));
        }

    }

    public static int[][] eliminarFilasImpares(int matriz[][]){

        int[][]matrizPar = new int[(matriz.length/2)][matriz.length];

        int par = 0;

        for (int i = 0; i < matrizPar.length; i++) {
            for (int j = 0; j < matrizPar[0].length; j++) {
                matrizPar[i][j] = matriz[par][j];
            }
            par += 2;
        }

return matrizPar;

    }

    public static int[][] eliminarFilasPares(int matriz[][]){
        int[][]matrizInpar = new int[(matriz.length/2)][matriz.length];

        int inpar = 1;

        for (int i = 0; i < matrizInpar.length; i++) {
            for (int j = 0; j < matrizInpar[0].length; j++) {
                matrizInpar[i][j] = matriz[inpar][j];
            }
            inpar += 2;
        }

        return matrizInpar;


    }
}
