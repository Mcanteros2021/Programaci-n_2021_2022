import java.util.Arrays;
import java.util.Scanner;

public class Ej3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduzca el tamaño de la matriz cuadrada");
        int tamaño = sc.nextInt();

        int[][] matriz = new int[tamaño][tamaño];

        for (int i = 0; i < matriz.length ; i++) {
            for (int j = 0; j < matriz[0].length ; j++) {
                matriz[i][j] = (int)(Math.random()*101 + 100);
            }
        }

        for (int[]x:matriz
             ) {
            System.out.println(Arrays.toString(x));
        }
        System.out.println();
        System.out.println("Hay un total de "+numPicos(matriz)+" casos");

    }


    public static int numPicos(int matriz[][]){

        int cont = 0;

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                if(caso(matriz, i,j,matriz.length) && caso2(matriz, i,j,matriz.length) && caso3(matriz, i,j,matriz.length) && caso4(matriz, i,j,matriz.length) && caso5(matriz, i,j,matriz.length) && caso6(matriz, i,j,matriz.length) && caso7(matriz, i,j,matriz.length) && caso8(matriz, i,j,matriz.length)) {
                    cont++;
                }
            }
        }
        return cont;
    }

    public static boolean caso(int[][]matriz,int x, int y, int largo){

        if(y + 1 != largo){
            if(matriz[x][y] >= matriz[x][y + 1]) {
                return true;
            }
            else {
                return false;
            }
        } else {
            return true;
        }

    }

    public static boolean caso2(int[][]matriz,int x, int y, int largo){

        if(y - 1 != -1 && x - 1 != -1){
            if(matriz[x][y] >= matriz[x - 1][y - 1]) {
                return true;
            }
            else {
                return false;
            }
        } else {
            return true;
        }

    }

    public static boolean caso3(int[][]matriz,int x, int y, int largo){

        if(y - 1 != -1 && x + 1 != largo){
            if(matriz[x][y] >= matriz[x + 1][y - 1]) {
                return true;
            }
            else {
                return false;
            }
        } else {
            return true;
        }

    }

    public static boolean caso4(int[][]matriz,int x, int y, int largo){

        if(y + 1 != largo && x - 1 != -1){
            if(matriz[x][y] >= matriz[x - 1][y + 1]) {
                return true;
            }
            else {
                return false;
            }
        } else {
            return true;
        }

    }

    public static boolean caso5(int[][]matriz,int x, int y, int largo){

        if(y - 1 != -1){
            if(matriz[x][y] >= matriz[x][y - 1]) {
                return true;
            }
            else {
                return false;
            }
        } else {
            return true;
        }

    }

    public static boolean caso6(int[][]matriz,int x, int y, int largo){

        if(y + 1 != largo && x + 1 != largo){
            if(matriz[x][y] >= matriz[x + 1][y + 1]) {
                return true;
            }
            else {
                return false;
            }
        } else {
            return true;
        }

    }
    public static boolean caso7(int[][]matriz,int x, int y, int largo){

        if(x + 1 != largo){
            if(matriz[x][y] >= matriz[x + 1][y]) {
                return true;
            }
            else {
                return false;
            }
        } else {
            return true;
        }

    }
    public static boolean caso8(int[][]matriz,int x, int y, int largo){

        if(x - 1 != -1){
            if(matriz[x][y] >= matriz[x - 1][y]) {
                return true;
            }
            else {
                return false;
            }
        } else {
            return true;
        }

    }

}
