import java.util.Arrays;

public class Ej1 {
    public static void main(String[] args) {

        int []a = {5,3,4,5,6,6,9,10,11};
        int []b = {5,4,5,8,6,9,10};


        System.out.println( Arrays.toString(interseccionVectores(a,b)));

    }

    public static int[] interseccionVectores( int[]v1,int[]v2){

      int [] interseccion = new int[0];

        for (int i = 0; i <v1.length ; i++) {
            for (int j = 0; j <v2.length; j++) {
                if(esta(v1[i],v2[j],interseccion) && v1[i] == v2[j]){
                    interseccion = Arrays.copyOf(interseccion,interseccion.length + 1);
                    interseccion[interseccion.length - 1] = v1[i];
                }
            }
        }
        Arrays.sort(interseccion);


        return interseccion;
    }



    public static boolean esta(int x, int y, int[]z){

        boolean esta = true;

        for (int i = 0; i < z.length ; i++) {
            if(x == z[i] || y == z[i]){
                esta = false;
            }
        }

        return esta;

    }
}
