import java.util.Arrays;

public class Ej4 {
    public static void main(String[] args) {

        int[][] bi = {{3,3,2,4,5},{9,5,2,5,6},{8,3,1,9,1}};


        for (int []x: bi
             ) {
            System.out.println(Arrays.toString(x));
        }

        System.out.println();

        for (int[]x:desplazarMatriz(bi,27)
             ) {
            System.out.println(Arrays.toString(x));
        }

    }

    public static int[][] desplazarMatriz(int[][] x, int columnas){

        int[][] desplazado = new int[x.length][x[0].length];

        for (int i = 0; i < x.length ; i++) {
            for (int j = 0; j < x[0].length ; j++) {
                desplazado[i][(columnas + j)%x[i].length] = x[i][j];
            }
        }

        return desplazado;
    }
}
