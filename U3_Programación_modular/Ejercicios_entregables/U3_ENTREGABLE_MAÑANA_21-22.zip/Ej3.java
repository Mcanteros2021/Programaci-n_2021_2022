import java.util.Arrays;
import java.util.Scanner;

public class Ej3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca el tamaño del cuadrado");

        int tamaño = sc.nextInt();

        int[][] cuadrado = new int[tamaño][tamaño];
        int[] diagonal = new int[0];
        int num = 0;
        int max = 0;
        int min = 65;
        int media = 0;


        for (int i = 0; i < cuadrado.length; i++) {
            for (int j = 0; j < cuadrado[i].length; j++) {
                num = (int)(Math.random()*47+19);
                cuadrado[i][j] = num;

                if(num > max){
                    max = cuadrado[i][j];
                }
                if(cuadrado[i][j] < min){
                    min = cuadrado[i][j];
                }

                media += num;
            }

        }
        for (int i = 0; i < cuadrado.length; i++) {
            diagonal = Arrays.copyOf(diagonal,diagonal.length +1);
            diagonal[diagonal.length - 1] = cuadrado[i][i];
        }

        for (int[] x: cuadrado
             ) {
            System.out.println(Arrays.toString(x));
        }



        System.out.println("Los numeros que componen la diagonal son "+ Arrays.toString(diagonal));
        System.out.println("El máximo es "+max+" el mínimo "+min+" y la media es "+media/ cuadrado.length);
        
        
    }
}
