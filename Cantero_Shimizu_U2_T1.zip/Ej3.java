public class Ej3 {
}
