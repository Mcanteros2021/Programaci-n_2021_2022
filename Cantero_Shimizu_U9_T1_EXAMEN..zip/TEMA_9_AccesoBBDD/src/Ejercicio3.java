import java.sql.*;


public class Ejercicio3 {

    public static void main(String[] args) throws SQLException {

        Connection con = ConexionDb.getConnection();

        PreparedStatement statement = con.prepareStatement("SELECT p.* from productlines p;");

        System.out.println("La consulta es : " + statement.toString());


        ResultSet rs = statement.executeQuery();

        while (rs.next()) {
            String productLine = rs.getString("productLine");
            String textDescription = rs.getString("textDescription");
            String htmlDescription = rs.getString("htmlDescription");


            System.out.println("-------------------------");
            System.out.println("Producline: " + productLine);
            System.out.println("TextDescription: " + textDescription);
            System.out.println("htmlDescription: " + htmlDescription);
            System.out.println("-------------------------");
        }







    }

}
