import java.sql.Connection;
import java.sql.SQLException;

public class Ejercicio4 {
    public static void main(String[] args) {
        Connection con=ConexionDb.getConnection();











    }


}
