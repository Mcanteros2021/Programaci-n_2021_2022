
import java.sql.*;


public class ConexionDb {
    private static Connection connextion=null;

    public static Connection getConnection() {

        try {
            if (connextion == null) {
                connextion = DriverManager.getConnection("jdbc:mariadb://localhost:3336/classicmodels?user=root&password=root"
                        + "&useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC");
                System.out.println("Connection Successful");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return (connextion);
    }

    public static void close(){
        try {
            if (connextion != null) connextion.close();
        } catch (SQLException e){
            System.err.println(e.getMessage());
        }
    }
}

