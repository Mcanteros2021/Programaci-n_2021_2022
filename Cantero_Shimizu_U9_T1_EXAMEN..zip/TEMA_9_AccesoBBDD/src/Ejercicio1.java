import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;

public class Ejercicio1 {
    public static void main(String[] args) {

        try{

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(new File("src/Restaurante.xml"));

            Node root = doc.getDocumentElement();

            System.out.println("Todo bien");

            Element plato = doc.createElement("plato");

            Element nombre = doc.createElement("nombre");
            nombre.setTextContent("Patatas fritas con huevo");

            Element precio = doc.createElement("precio");
            precio.setTextContent("4.5");

            plato.appendChild(nombre);
            plato.appendChild(precio);

            root.appendChild(plato);




            Element disponible1 = doc.createElement("disponible");
            disponible1.setTextContent("si");
            Element disponible2 = doc.createElement("disponible");
            disponible2.setTextContent("no");
            Element disponible3 = doc.createElement("disponible");
            disponible3.setTextContent("si");
            Element disponible4 = doc.createElement("disponible");
            disponible4.setTextContent("no");


            doc.getElementsByTagName("plato").item(0).appendChild(disponible1);
            doc.getElementsByTagName("plato").item(1).appendChild(disponible2);
            doc.getElementsByTagName("plato").item(2).appendChild(disponible3);
            doc.getElementsByTagName("plato").item(3).appendChild(disponible4);


            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer transformer = tf.newTransformer();

            transformer.setOutputProperty( OutputKeys.INDENT, "yes" );
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
            transformer.setOutputProperty( OutputKeys.OMIT_XML_DECLARATION, "no" );
            transformer.setOutputProperty( OutputKeys.METHOD, "xml" );
            transformer.setOutputProperty("http://www.oracle.com/xml/is-standalone", "yes");

            DOMSource origenDOM = new DOMSource(root);


            File nuevoRestaurante = new File("src/examen2.xml");
            StreamResult destino = new StreamResult(nuevoRestaurante);


            transformer.transform(origenDOM,destino);


        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (SAXException e) {
            throw new RuntimeException(e);
        } catch (TransformerConfigurationException e) {
            throw new RuntimeException(e);
        } catch (TransformerException e) {
            throw new RuntimeException(e);
        }

    }
}
