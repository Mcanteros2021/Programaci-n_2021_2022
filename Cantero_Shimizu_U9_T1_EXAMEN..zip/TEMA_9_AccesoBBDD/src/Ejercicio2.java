import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Ejercicio2 {
    public static void main(String[] args) throws FileNotFoundException, XMLStreamException {


        try {

            XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
            XMLEventReader xmlReader = xmlInputFactory.createXMLEventReader(new FileInputStream("Restaurante.xml"));

            System.out.println("Bien");

        }catch (Exception e){

            System.out.println("Error");

        }



    }
}
